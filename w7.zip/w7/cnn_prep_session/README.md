# Convolutional Neural Networks (CNNs)  🤓
How to resolve an Image CAPTCHA system with Convolutional Neural Networks (CNNs)

# Getting Started 🎁
1. Install requirements:
   ```shell
   pip install -r requirements.txt --no-cache-dir --user
   ```

3. Open the notebook

4. Enjoy


# Contribute 🛠️
**Your Amazing TA** [Team Correlation One](https://www.correlation-one.com/)


# Version Control ✒️
* **Version 1**- *Juan Garcia* - DS4A v3
* **Version 2** - *Adonai Vera* - DS4A v5 - [AdonaiVera](https://github.com/AdonaiVera)
